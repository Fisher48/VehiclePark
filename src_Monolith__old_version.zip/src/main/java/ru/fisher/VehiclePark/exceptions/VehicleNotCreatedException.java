package ru.fisher.VehiclePark.exceptions;

public class VehicleNotCreatedException extends RuntimeException {

    public VehicleNotCreatedException(String message) {
        super(message);
    }
}
