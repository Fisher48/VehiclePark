package ru.fisher.VehiclePark.exceptions;

public class GpxParsingException extends RuntimeException {
    public GpxParsingException(String message) {
        super(message);
    }
}
