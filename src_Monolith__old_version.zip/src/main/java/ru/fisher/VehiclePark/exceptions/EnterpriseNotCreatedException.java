package ru.fisher.VehiclePark.exceptions;

public class EnterpriseNotCreatedException extends RuntimeException {

    public EnterpriseNotCreatedException(String message) {
        super(message);
    }
}
