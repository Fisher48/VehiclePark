package ru.fisher.VehiclePark.exceptions;

public class EnterpriseNotUpdatedException extends RuntimeException {

    public EnterpriseNotUpdatedException(String message) {
        super(message);
    }
}
