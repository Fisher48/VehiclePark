package ru.fisher.VehiclePark.exceptions;

public class VehicleNotUpdatedException extends RuntimeException {

    public VehicleNotUpdatedException (String message) {
        super(message);
    }
}
