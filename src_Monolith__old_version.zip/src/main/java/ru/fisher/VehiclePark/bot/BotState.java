package ru.fisher.VehiclePark.bot;

public enum BotState {
    START,
    ENTERPRISE_WAITING_NAME,
    VEHICLE_WAITING_NUMBER,
    PERIOD_SELECTION,
    WAITING_START_DATE,
    WAITING_END_DATE
}
