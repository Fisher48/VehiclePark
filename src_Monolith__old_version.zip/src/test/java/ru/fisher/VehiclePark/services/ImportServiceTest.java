//package ru.fisher.VehiclePark.services;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.springframework.web.multipart.MultipartFile;
//import ru.fisher.VehiclePark.dto.ImportDTO;
//import ru.fisher.VehiclePark.dto.TripImportData;
//import ru.fisher.VehiclePark.dto.VehicleDTO;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.when;
//
//class ImportServiceTest {
//
//    @Mock
//    private MultipartFile file;
//
//    @InjectMocks
//    private ImportService importService;
//
//    @BeforeEach
//    public void setUp() {
//        MockitoAnnotations.openMocks(this);
//    }
//
//    @Test
//    public void testParseCsvFile() throws Exception {
//        // Подготовка тестовых данных
//        String csvContent = "Enterprise ID,5,Test Enterprise,Moscow,UTC+3\n" +
//                "Vehicle ID,Brand ID,Number,Price,Year,Mileage\n" +
//                "1,1,A123BC,100000,2018,50000\n" +
//                "Trip ID,Vehicle ID,Start Time,End Time,Start Point,End Point,Duration\n" +
//                "1,1,2023/10/01 08:00,2023/10/01 08:30,Москва, ул. Ленина, 10,Москва, ул. Пушкина, 5,0 hours, 30 minutes";
//
//        when(file.getInputStream()).thenReturn(new java.io.ByteArrayInputStream(csvContent.getBytes()));
//
//        // Вызов метода
//        ImportDTO result = importService.parseCsvFile(file);
//
//        // Проверка результатов
//        assertEquals("Test Enterprise", result.getEnterprise().getName());
//        assertEquals(1, result.getVehicles().size());
//        assertEquals(1, result.getTrips().size());
//
//        VehicleDTO vehicle = result.getVehicles().get(0);
//        assertEquals("A123BC", vehicle.getNumber());
//
//        TripImportData trip = result.getTrips().get(0);
//        assertEquals("2023/10/01 08:00", trip.getStartTime());
//    }
//}