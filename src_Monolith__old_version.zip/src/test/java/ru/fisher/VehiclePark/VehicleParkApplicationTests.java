package ru.fisher.VehiclePark;

import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@AutoConfigureMockMvc
class VehicleParkApplicationTests {

//	@Autowired
//	private MockMvc mockMvc;
//
//	@Autowired
//	private ObjectMapper objectMapper;
//
//	@Autowired
//	private VehicleRepository vehicleRepository;
//
//	@Autowired
//	private Faker faker;
//
//	private Vehicle testVehicle;
//	private Brand testBrand;
//
//	@BeforeEach
//	public void setUp() {
//		testVehicle = Instancio.of(Vehicle.class)
//				.ignore(Select.field(Vehicle::getId))
//				.supply(Select.field(Vehicle::getNumber), () -> faker.number())
//				.supply(Select.field(Vehicle::getPrice), () -> faker.money())
//				.supply(Select.field(Vehicle::getMileage), () -> faker.idNumber())
//				.supply(Select.field(Vehicle::getYearOfCarProduction), () -> faker.oscarMovie().getYear())
//				.create();
//
//		testBrand = Instancio.of(Brand.class)
//				.ignore(Select.field(Brand::getId))
//				.supply(Select.field(Brand::getBrandName), () -> faker.brand().car())
//				.supply(Select.field(Brand::getType), () -> faker.vehicle().carType())
//				.supply(Select.field(Brand::getFuelTank), () -> faker.number().digit())
//				.supply(Select.field(Brand::getLoadCapacity), () -> faker.number().digit())
//				.supply(Select.field(Brand::getNumberOfSeats), () -> faker.number().digit())
//				.create();
//	}
//
//
//
//	@Test
//	void contextLoads() {
//	}

}
